from user import User

my_user = User('Ivan', 'Petrov')
print(my_user.getFirstName())
print(my_user.getLastName())
print(my_user.getFullName())
